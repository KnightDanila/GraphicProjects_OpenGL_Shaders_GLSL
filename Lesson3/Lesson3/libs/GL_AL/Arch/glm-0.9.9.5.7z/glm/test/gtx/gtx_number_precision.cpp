#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/number_precision.hpp>

int main()
{
	int Error(0);

	return Error;
}
